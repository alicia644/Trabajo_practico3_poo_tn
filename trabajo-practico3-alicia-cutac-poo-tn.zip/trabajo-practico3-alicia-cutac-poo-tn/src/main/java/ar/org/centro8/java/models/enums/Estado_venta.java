package ar.org.centro8.java.models.enums;

public enum Estado_venta {
    PENDIENTE,PAGADO,CANCELADO;

}
