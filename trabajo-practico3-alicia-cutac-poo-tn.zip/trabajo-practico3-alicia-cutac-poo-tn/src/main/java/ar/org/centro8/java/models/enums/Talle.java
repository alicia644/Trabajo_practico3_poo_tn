package ar.org.centro8.java.models.enums;

public enum Talle {
    S,M,L,XL,XXL;

}
