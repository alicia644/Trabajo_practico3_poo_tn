package ar.org.centro8.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajoPractico3AliciaCutacPooTnApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabajoPractico3AliciaCutacPooTnApplication.class, args);
	}

}
