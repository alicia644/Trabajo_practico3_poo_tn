package ar.org.centro8.java.models.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Detalle_venta {
    private int id_venta;
    private int id_producto;
    private int cantidad;
    private double subtotal;
}
