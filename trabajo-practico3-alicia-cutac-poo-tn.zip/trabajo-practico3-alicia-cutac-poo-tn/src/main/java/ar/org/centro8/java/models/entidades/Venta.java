package ar.org.centro8.java.models.entidades;

import java.time.LocalDate;

import ar.org.centro8.java.models.enums.Estado_venta;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Venta {
    private int id_venta;
    private int id_cliente;
    private LocalDate fecha_venta;
    private double total;
    private Estado_venta estado_venta;
}
