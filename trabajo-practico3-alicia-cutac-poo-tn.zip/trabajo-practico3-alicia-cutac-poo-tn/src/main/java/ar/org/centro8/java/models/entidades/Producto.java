package ar.org.centro8.java.models.entidades;

import ar.org.centro8.java.models.enums.Talle;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Producto {
    private int id_producto;
    private String tipo_prenda;
    private Talle talle;
    private String color;
    private double precio;
    private int stock;
    private double precio_costo;
}
